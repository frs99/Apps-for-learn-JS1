// Dec 04 / 2020
// Fares Djefaflia
// حساب كم عمرك
/*function Date_of_Birth(years, months, days){
    var yr, dy, mn;
    yr = //year now;
    dy = // day now;
    mn = // month now;
    function year(years){
        if (years < yr){
            document.write("<br>عمرك بالسنة هو: ")
            document.write( yr - years);
        }
        else if (years > yr){
            document.write("هناك حطأ في تاريخ الميلاد");
        }
    }
    year(years);

    function month(months){
        document.write("<br> عمرك بالشهر هو: ")
        document.write(mn - months)
    }
    month(months);

    function day(days){
        
        if(dy < days){
            dy = dy + 30;
            mn = mn - 1;  
        }
        document.write("<br> عمرك باليوم هو: ")
        document.write(dy - days);
    }
    day(days);
}

Date_of_Birth(1999, 02, 22);*/
