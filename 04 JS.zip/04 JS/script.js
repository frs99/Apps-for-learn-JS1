// Oct 31 2020
//*Fares Djefaflia

/*function maxnum(a, b, c){
    var max, maxa, maxb, maxc;
    maxa = a;
    maxb = b;
    maxc = c;
    max = "MAX NUMBER IS:";

    if (a > b && a > c){
        document.write( max + maxa);
    }
    else if (b > a && b >c){
        document.write( max + maxb);
    }
    else if (c > a && c >b){
        document.write( max + maxc);
    }
    else{
        document.write("error");
    }
}
maxnum(152520, 25654546544250, 352999995520);
*/

/*function mynum (a,b,c){
    var max, text, erroe;
    text = "your number is: "
    error = "ERROR: There cannot be one number equal to another"

    if (a > b){
        if(a > c){
            max = a;
        }
        else if (a < c){
            max = c;
        }
        document.write(text + max);
    }
    else if (a < b){
        if (b > c){
            max = b;
        }
        else if (b < c){
            max = c;
        }
        document.write(text + max);
    }
    
}
mynum (10, 10725420, 150250);*/


function mynum (a,b,c){
    var max, text, error;
    text = "<br>your number is: "
    error = "ERROR: There cannot be one number equal to another: "

    
    if (a > b){
        if(a > c){
            max = a;
        }
        else if (a < c){
            max = c;
        }
        else if(a = c){
            max = "error"
            document.write(error + "A = C")
        }

    }
    else if (a < b){
        if (b > c){
            max = b;
        }
        else if (b < c){
            max = c;
        }
        else if(b = c){
            max = "error"
            document.write(error + "B = C")
        }
    }
    else if(a=b){
        max = "error"
        document.write(error + "A = B")
    }
    
    document.write(text + max);
    
}
mynum (50, 5, 10);
