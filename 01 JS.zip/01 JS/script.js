// #01 for JS
// *Fares Djefaflia Oct 22 1:15pm - start
//01
function lmo3adl(){

    var arab, math, sec, phy, all, mo3adl;
    arab = 12;
    math = 13;
    sec = 16;
    phy = 19;
    all = arab + math + sec + phy;
    mo3adl = all / 4;

    if (mo3adl < 10){
        document.write(mo3adl + "(you Bad)")
    }
    else if (mo3adl > 10 && mo3adl < 20){
        document.write(mo3adl + "<br>(You Good)")
    }
    else{
        document.write("ERROR")
    }
}
lmo3adl();

//02
/* var lmo3adl = function(){

    var arab, math, sec, phy, all, mo3adl;
    arab = 12;
    math = 13;
    sec = 16;
    phy = 19;
    all = arab + math + sec + phy;
    mo3adl = all / 4;

    

    if (mo3adl < 10){
        document.write(mo3adl + "(you Bad)")
    }
    else if (mo3adl > 10 && mo3adl < 20){
        document.write(mo3adl + "<br>(You Good)")
    }
    else{
        document.write("ERROR")
    }
}
lmo3adl();
*/