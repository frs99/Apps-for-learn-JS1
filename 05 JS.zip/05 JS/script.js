
//Dec 14 2020
//Fares Djefaflia


var yourAge = prompt("write your age here ..");
if (yourAge < 18){
    document.getElementById("txt2").innerHTML = " | Im Sorry bro you cant open this";
    //document.getElementById("txtage").innerHTML = yourAge;
}
else if (yourAge >= 18){
    document.getElementById("txt2").innerHTML = " | Hello and Welcome to the site";
    //document.getElementById("txtage").innerHTML = yourAge;
}
document.getElementById("txtage").innerHTML = yourAge;
