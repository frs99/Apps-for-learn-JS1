//#02 javascript
//fares djefaflia Oct 26 2020


function yourpassword (password){

    var lower = 5;
    var hard = 10;

    if (password.length < lower){
        document.write("<br> your password: " + password)
        document.write("<br>The number of characters is less than 5. Please add more characters");
    }
    else if (password.length > hard){
        document.write("<br> your password: " + password)
        document.write("<br>The number of characters is greater than 10. Please add between 5 and 10 characters only");
    }
    else if (password.length  > lower && password.length < hard){
        document.write("<br> your password: " + password)
        document.write("<br>this good password, THANKS");
    }
    else{
        document.write("<br> your password: " + password)
        document.write("<br>error")
    }
}

var pass1 = "dsvv";
//var pass2 = "dsvv";
//var pass2 = "dsvv";
yourpassword(pass1);
//yourpassword(pass2);
//yourpassword(pass2);


/*function mo3adl(name,note1,note2){

    var total = note1 + note2;
    var all = total / 2
    return "hello " + name + " your note is:" + all ;
}
document.write(mo3adl("fares", 20 , 15))*/